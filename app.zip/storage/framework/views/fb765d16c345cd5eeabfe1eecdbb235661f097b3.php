<h1>
    hello nav
</h1>
<?php /**PATH C:\wamp64\www\laravel-example\resources\views/info/layouts/Navbar.blade.php ENDPATH**/ ?>