<x-app-layout>

    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
     Header
        </h2>
    </x-slot>
    <main>
            <h1 class="text-center text-red-600">
               HELLO SOAT API LINE
            </h1>
    </main>

</x-app-layout>
%
